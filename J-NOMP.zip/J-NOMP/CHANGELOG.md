# Changelog

### 20161127
  * Fixed payment processor crashes
  * Fixed varDiff and set default to 0.125
  * Fixed merkleRoot issue with multiple transactions in each block
  * Fixed incorrect hashrates
  * Begin compatibility testing with Node 7+
  * Added t_address -> z_address -> t_address coin transfer function
  

